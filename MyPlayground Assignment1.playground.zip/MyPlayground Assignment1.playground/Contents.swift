import UIKit

var greeting = "Hello, playground"
 
//cheack each element is even or odd


var a1 = [2,3,5,9,7,6,8]
print(a1)
for p in a1{
    if(p % 2 == 0){
        print("\(p) is even")
    }else{
        print("\(p) is odd")
    }
}




// sum of all element in array

var Numbers : [Int] = [10,20,70,60,45,80]
var a = 0
for b in Numbers{
    a+=b
}
print("sum of elements of array is = \(a)")


// sort array in asecending order

var num = [2,7,19,20,40,60,87,45,34]
num.sort(by:<)
print(num)

// sort array in desending order
  
var num1 = [7,19,56,34,37,89,90,76]
num1.sort(by:<)
print(num1)

// reverse string input -- bitcode output

var myString = "Bitcode"
var revString = ""
for eachElement in myString{
    revString = ("\(eachElement)") + revString
}
print(revString)



// using  switch case - perfrom all mathematical operation

var choice = "+"
var Number1 : Int = 90
var Numbwer2 : Int = 54
switch choice{
case "+":
    let Addition = Number1 + Numbwer2
    print("Addition of two numbers\(Addition)")
    break
case "-":
    let Substraction = Number1 - Numbwer2
    print("Substraction of two numbers\(Substraction)")
    break
case "*":
    let Multiplication = Number1 * Numbwer2
    print("Multiplication of two numbers\(Multiplication)")
    break
case "/":
    let Divide = Number1 / Numbwer2
    print("Division of two numbers\(Divide)")
    break
default :
    print("Invalid choice")
    break
}





//using function perfrom all mathematical operation
//addition
func addition (number num1 : Int , number num2 : Int){
    print(num1+num2)
}
addition(number: 100 , number: 10)
//substraction
func substract (number num1 : Int ,number num2 : Int){
    print(num1-num2)
}
substract(number: 90 , number: 25)
//multiplication
func multiply (number num1 : Int, number num2 : Int){
    print(num1*num2)
}
multiply(number:5, number: 6)
//division
func divide (number num1 :Int, number num2: Int){
    print(num1/num2)
}
divide(number: 65, number: 3)


// find minimun elelment from array

var b = [4,9,3,21,7,6,2]
print(b.min()!)
